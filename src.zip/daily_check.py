import logging as log
from src.client.schema_info_provider import SchemaInfoProvider
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter
from datetime import datetime

# Configure logging
log.basicConfig(level=log.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Create an instance of SchemaInfoProvider
provider = SchemaInfoProvider()

# Call the get_daily_data function
daily_data = provider.get_daily_data()

# Log the results
log.info(f'Daily Data: {daily_data}')

# Get the current date in YYYYmmdd format
current_date = datetime.now().strftime('%Y%m%d')

# Define the Excel file path with the current date
excel_file_path = rf"C:\Users\admin\OneDrive\바탕 화면\고객사발송한도별사용금액현황_{current_date}.xlsx"

wb = Workbook()
ws = wb.active
ws.title = 'Daily Data'

# Define styles
header_fill = PatternFill(start_color='D3D3D3', end_color='D3D3D3', fill_type='solid')
thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
center_alignment = Alignment(horizontal='center', vertical='center')

# Write the headers
headers = list(daily_data[0].keys())
ws.append(headers)

for col_num, header in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col_num)
    cell.fill = header_fill
    cell.border = thin_border
    cell.alignment = center_alignment
    ws.column_dimensions[get_column_letter(col_num)].auto_size = True

# Write the data
for row_num, data in enumerate(daily_data, 2):
    for col_num, value in enumerate(data.values(), 1):
        cell = ws.cell(row=row_num, column=col_num, value=value)
        cell.border = thin_border

# Adjust column widths
for col in ws.columns:
    max_length = 0
    column = col[0].column_letter
    for cell in col:
        try:
            if len(str(cell.value)) > max_length:
                max_length = len(cell.value)
        except:
            pass
    adjusted_width = (max_length + 10)
    ws.column_dimensions[column].width = adjusted_width

# Save the workbook to the specified file path
wb.save(excel_file_path)

log.info(f'Excel file saved at {excel_file_path}')