

class AlimTalk(object):

    def __init__(self):
        pass